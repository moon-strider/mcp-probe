from mcp_probe.cli import main

main()
