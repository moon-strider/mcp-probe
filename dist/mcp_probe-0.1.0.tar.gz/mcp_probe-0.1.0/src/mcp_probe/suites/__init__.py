from mcp_probe.suites.base import BaseSuite, check

__all__ = ["BaseSuite", "check"]
